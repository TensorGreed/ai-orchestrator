L2M audit bundle
================

Execution:      886ad29d-1c56-4af1-95c9-98313f188e7b
Workflow:       wf-support-audit (Support answer with citations)
Status:         success
Finished:       2026-10-22T16:38:04.701Z
Manifest:       sha256 fdbbf3632246f303fe602ceba3688f28bac49af3d8cc6a7b80045be09e08122a

Contents
--------
manifest.json          The signed run manifest (canonical JSON: sorted keys, no whitespace).
signature.json         Ed25519 signature, signing key id and public key, and the signed index:
                       the SHA-256 digest and size of every other file in this bundle.
workflow.json          The workflow as it ran (secret-looking literals redacted). Its canonical
                       JSON hashes to manifest.workflow.hash.
execution/run.json     The execution record as stored (redacted input, output, status).
execution/nodes/       Each node's input and output as stored in execution history (redacted).
execution/trace.json   Node timings, MCP tool-call telemetry and guard events (masked evidence).
execution/logs.jsonl   Node activity, errors, warnings and the run's audit-log entries.
outputs/               Files the run produced (PDFs, charts, documents), when there are any.

Verify offline
--------------
1. Get the deployment's public key from an admin (Settings > Audit signing, or
   GET /api/audit/signing-keys) through a channel you trust.
2. Run:  l2m audit verify <this-bundle.zip> --public-key <key file or base64>
   It checks the signature, every file digest against the signed index, that no
   file was added or removed, and the manifest digest. No network access is needed.

Without --public-key the key inside signature.json is used: that proves the bundle
was not changed after signing, but not who signed it.

Manifest fields hold digests (SHA-256 of canonical JSON) of node inputs and outputs,
not the payloads; compare them with the files under execution/nodes/. Secrets appear
only as secretRef.secretId; resolved secret values are never included.
