L2M audit bundle
================

Execution:      2aee414b-0021-48af-98ad-263c18facb6b
Workflow:       wf-audit (Audited support)
Status:         success
Finished:       2026-10-22T17:09:53.493Z
Manifest:       sha256 0ac768d222aef37deaed79d4b6e2b4ea647c73db78a9710b8af40c9669daab6b

Contents
--------
manifest.json          The signed run manifest (canonical JSON: sorted keys, no whitespace).
signature.json         Ed25519 signature, signing key id and public key, and the signed index:
                       the SHA-256 digest and size of every other file in this bundle.
workflow.json          The workflow as it ran (secret-looking literals redacted). Its canonical
                       JSON hashes to manifest.workflow.hash.
execution/run.json     The execution record as stored (redacted input, output, status).
execution/nodes/       Each node's input and output as stored in execution history (redacted).
execution/trace.json   Node timings, MCP tool-call telemetry and guard events (masked evidence).
execution/logs.jsonl   Node activity, errors, warnings and the run's audit-log entries
                       (actor user id and role; actor emails only in bundles exported by an admin).
outputs/               Files the run produced (PDFs, charts, documents), when there are any.
redactions.json        Which files had secret values replaced, and which outputs were left out.

Verify offline
--------------
1. Get the deployment's public key from an admin (Settings > Audit signing, or
   GET /api/audit/signing-keys) through a channel you trust.
2. Run:  l2m audit verify <this-bundle.zip> --public-key <key file or base64>
   It checks the signature, every file digest against the signed index, that no
   file was added or removed, and the manifest digest. No network access is needed.

Only the deployment's public key, obtained through a channel you trust, proves who
signed this bundle. Without --public-key the verifier checks the signature against
the key inside signature.json and reports SIGNER NOT VERIFIED (exit code 3): that only
shows the bundle is internally consistent. Anyone who changes a bundle can re-sign it
with a key of their own, so it proves neither who signed it nor that it is unchanged.

Manifest fields hold digests (SHA-256 of canonical JSON) of node inputs and outputs,
not the payloads; compare them with the files under execution/nodes/. The digests are
not salted: for a small or guessable value, a digest confirms a correct guess.

Secrets: node configs keep secretRef.secretId only, and literals under credential-like
keys are [REDACTED]. Every secret value the deployment holds (its secret store, cached
external secrets, provider keys from its environment; values of 6 characters or more)
is replaced with [REDACTED] in the manifest and in every JSON, log and text file. Binary
outputs containing one are left out (see redactions.json). Content compressed inside a
binary file (PDF streams, DOCX/XLSX parts) is not inspected.
